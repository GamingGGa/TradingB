# TradingB
Trade in Binance when perpetual price is lower than actual stock price
